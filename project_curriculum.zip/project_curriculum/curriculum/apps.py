from django.apps import AppConfig


class CurriculumConfig(AppConfig):
    name = 'curriculum'
